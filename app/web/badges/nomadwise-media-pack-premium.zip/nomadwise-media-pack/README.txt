Nomadwise website badges: Premium
Badge: "Verified by nomadwise.io (with the tick)"
Pill: 212x44 px   Square: 104x104 px   (PNG at @1x, @2x and @3x, plus SVG)
Styles: 1-white (works on most websites), 2-red, 3-outline (white lines, see-through, for dark websites and photos)
Free to use. If you post it, tag @nomadwise.io on Instagram and we will share it.
